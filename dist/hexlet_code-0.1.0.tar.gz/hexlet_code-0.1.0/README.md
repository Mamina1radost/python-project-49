### Hexlet tests and linter status:
[![Actions Status](https://github.com/Mamina1radost/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Mamina1radost/python-project-49/actions)

### Codeclimate
[![Maintainability](https://api.codeclimate.com/v1/badges/d13ef4f7d80d89a90ef7/maintainability)](https://codeclimate.com/github/Mamina1radost/python-project-49/maintainability)

### Аскинема
https://asciinema.org/a/MZuBwLiUmgbQhhSXd8goFZrij
https://asciinema.org/a/0TImRdezGUNiqIJMr9d4MLN7m
https://asciinema.org/a/B1JOe4FJfHoxyZzjkuhIz8I90
https://asciinema.org/a/mianbEqhsgliEK6iFiAthwDa4