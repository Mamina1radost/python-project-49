### Hexlet tests and linter status:
[![Actions Status](https://github.com/Mamina1radost/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Mamina1radost/python-project-49/actions)

### Codeclimate
[![Maintainability](https://api.codeclimate.com/v1/badges/d13ef4f7d80d89a90ef7/maintainability)](https://codeclimate.com/github/Mamina1radost/python-project-49/maintainability)